create
    definer = root@localhost procedure find_movie_by_name(IN words varchar(50))
BEGIN
select movies.name,imdb,poster, trailer,description,countries.name country,movies.id from movies join countries on movies.country_id=countries.id
where movies.name like concat('%',words,'%')
order by movies.name;
END;


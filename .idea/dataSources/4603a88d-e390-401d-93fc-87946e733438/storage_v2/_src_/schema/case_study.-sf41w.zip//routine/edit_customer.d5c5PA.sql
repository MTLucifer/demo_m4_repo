create
    definer = root@localhost procedure edit_customer(IN cus_phone varchar(50), IN cus_name varchar(50),
                                                     IN cus_facility varchar(50), IN cus_time timestamp,
                                                     IN cus_status varchar(50), IN cus_id int)
BEGIN
UPDATE `case_study`.`customers` SET 
`phone` = cus_phone, 
`name` = cus_name, 
`facility` = cus_facility, 
`time` = cus_time, 
`status` = cus_status WHERE (`id` = cus_id);
END;


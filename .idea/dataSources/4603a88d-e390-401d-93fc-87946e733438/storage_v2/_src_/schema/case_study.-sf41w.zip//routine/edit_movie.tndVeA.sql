create
    definer = root@localhost procedure edit_movie(IN mov_name varchar(50), IN mov_country_id int, IN mov_imdb float,
                                                  IN mov_poster varchar(225), IN mov_trailer varchar(50),
                                                  IN mov_description longtext, IN mov_id int)
BEGIN
UPDATE `case_study`.`movies` SET 
`name` = mov_name, 
`country_id` = mov_country_id, 
`imdb` = mov_imdb, 
`poster` = mov_poster, 
`trailer` = mov_trailer, 
`description` = mov_description
WHERE (`id` = mov_id);
END;


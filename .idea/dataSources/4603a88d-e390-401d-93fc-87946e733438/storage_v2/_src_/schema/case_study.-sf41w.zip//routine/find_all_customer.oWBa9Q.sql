create
    definer = root@localhost procedure find_all_customer()
BEGIN
select * from customers
order by customers.time;
END;


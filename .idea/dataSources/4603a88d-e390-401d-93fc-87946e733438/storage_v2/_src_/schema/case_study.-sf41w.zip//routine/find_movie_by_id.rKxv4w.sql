create
    definer = root@localhost procedure find_movie_by_id(IN mov_id int)
BEGIN
select movies.name,imdb,poster, trailer,description,countries.name country from movies join countries on movies.country_id=countries.id
where movies.id = mov_id;
END;


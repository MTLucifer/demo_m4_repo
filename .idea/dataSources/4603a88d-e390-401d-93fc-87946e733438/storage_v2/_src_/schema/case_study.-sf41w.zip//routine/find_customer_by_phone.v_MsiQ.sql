create
    definer = root@localhost procedure find_customer_by_phone(IN phone_num int)
BEGIN
select * from customers
where phone like concat('%',phone_num)
order by customers.time;
END;

